<?php if(Auth::check()): ?>
   <script>
        history.go(-1);
   </script>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-black text-white">
                <div class="card-header h3 text-center">LOGIN</div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login-user')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if(Session::get('info')): ?>
                        <div class="alert alert-info" id="alert-message">
                            <?php echo e(Session::get('info')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(Session::get('infoconfirm')): ?>
                        <div class="alert alert-info" id="alert-message">
                            <?php echo e(Session::get('infoconfirm')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-danger" id="alert-message">
                            <ul class="list-unstyled">
                                <li>
                                    <?php echo e(Session::get('message')); ?>

                                </li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success" id="alert-message">
                        <ul class="list-unstyled">
                            <li>
                                <?php echo e(Session::get('success')); ?>

                            </li>
                        </ul>
                    </div>
                <?php endif; ?>
                        <div class="row mb-3">
                            <label for="email"
                                class="col-md-3 col-form-label text-right"><?php echo e(__('E-Mail Address')); ?></label>
                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password"
                                class="col-md-3 col-form-label text-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    required autocomplete="current-password">
                                    <span toggle="#password" class="fa fa-fw fa-eye field-icon toggle-password text-dark"
                                    style = " float: right;margin-right : 10px; margin-top: -25px;position: relative;z-index: 2;"></span>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        

                        <div class="col-md-6 offset-md-3 mt-3">
                            <input type="submit" class="btn text-white" style="background-color : #aa0000;"
                                value="LogIn" >
                        </div>
                        <div class="col-md-6 offset-md-3 mt-3 ">
                            <?php if(Route::has('password.request')): ?>
                            <a class="btn btn-link text-white" href="<?php echo e(route('password.request')); ?>">
                                Forgot Your Password?
                            </a>
                            <?php endif; ?>
                            <?php if(Route::has('register')): ?>
                            <a class="btn btn-link text-white" href="<?php echo e(route('register')); ?>">
                                Register an Account
                            </a>
                            <?php endif; ?>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>

<script type="text/javascript">

$(function(){
    setTimeout(function(){
        $("#alert-message").hide();
        }, 4000);
      });

$(".toggle-password").click(function() {
$(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});

$("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
    $("#success-alert").slideUp(500);
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/auth/login.blade.php ENDPATH**/ ?>