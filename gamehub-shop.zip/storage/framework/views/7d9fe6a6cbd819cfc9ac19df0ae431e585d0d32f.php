<?php $__env->startSection('content'); ?>
    <div class="container">
            <form action="<?php echo e(route('more.product')); ?>" method="GET">
                <div class="row mb-3">
                    <div class="col-md-8">
                        <input type="text" name="search" class="form-control" placeholder="Search....">
                    </div>
                    <div class="col-4">
                        <button type="submit" class="btn btn-secondary">Search</button>
                    </div>
                </div>
            </form>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col">
                <div class="card shadow-sm">
                    <img src="<?php echo e(Storage::url($product->image)); ?>" alt="" style="height: 300px;
                    object-fit: contain;">
                    <div class="card-body">
                        <p><b><?php echo e($product->name); ?></b></p>
                        <p class="card-text"><?php echo Str::limit($product->description,120); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="btn-group">
                                <a href="/product/<?php echo e($product->id); ?>">
                                <button type="button" class="btn btn-sm btn-outline-success">View</button>
                                </a>
                                <a href="<?php echo e(route('add.cart',[$product->id])); ?>">
                                    <button type="button" class="btn btn-sm btn-outline-primary">Add to cart</button>
                                </a>
                            </div>
                            <small class="text-muted"><?php echo e($product->price); ?> MMK</small>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="paginate mt-3">
            <?php echo e($products->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/all-product.blade.php ENDPATH**/ ?>