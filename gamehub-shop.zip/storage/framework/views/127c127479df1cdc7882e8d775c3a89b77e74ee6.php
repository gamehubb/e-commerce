<?php $__env->startSection('content'); ?>
    <div class="container">
      <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="alert alert-danger"><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Image</th>
                <th scope="col">Product</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Remove</th>
              </tr>
            </thead>
            <tbody>
                <?php if($cart): ?>
                <?php 
                    $i=1
                ?>
            <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($i++); ?></th>
                <td><img src="<?php echo e(Storage::url($product['image'])); ?>" alt="" width="100"></td>
                <td><?php echo e($product['name']); ?></td>
                <td><?php echo e($product['price']); ?></td>
                <td>
                    <form action="<?php echo e(route('cart.update',$product['id'])); ?>" method="post"><?php echo csrf_field(); ?>
                      <input type="text" name="qty" value="<?php echo e($product['qty']); ?>">
                        <button class="btn btn-secondary btn-sm">
                          <i class="fas fa-sync"></i> Update
                        </button>
                    </form>
                </td>
                <td>
                  <form action="<?php echo e(route('cart.remove',$product['id'])); ?>" method="post"><?php echo csrf_field(); ?>
                    <button class="btn btn-danger btn-sm">x</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <hr>
          <div class="cart-footer">
              <button class="btn btn-primary mt-3 btn-sm">Continue Shopping</button>
              <span class="mt-3" style="margin-left: 300px;">Total Price: <?php echo e($cart->totalPrice); ?> </span>
              <a href="<?php echo e(route('cart.checkout',[$cart->totalPrice])); ?>"><button class="btn btn-info mt-3 btn-sm" style="float:right">Checkout</button></a>
          </div>
          <?php else: ?>
          <td>Your Cart is Empty</td>
          <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/cart.blade.php ENDPATH**/ ?>