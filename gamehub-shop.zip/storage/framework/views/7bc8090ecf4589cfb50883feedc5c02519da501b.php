<?php $__env->startSection('content'); ?>
<div class="container  bg-dark">
    <div class="row text-white p-4">
        <div class="col-md-3 text-center p-2" style="border-width: 1px; border-color: rgb(27, 27, 27); border-radius : 25px;">             
               <img src="<?php echo e(Storage::url($products->productDetail[0]['image_1'])); ?>" alt="" id="productImg"
               style=" height: 200px;border-radius : 25px;">
               <?php $__currentLoopData = $products->productDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <span class="" style="color: <?php echo e($item->color); ?>;font-size :35px ;cursor:pointer;"  onclick="changeImage('<?php echo e(Storage::url($item->image_1)); ?>')">●</span>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
           
        </div>
        <div class="col-md-3 m-3"  >     
            <p class="h3"> <b><?php echo e($products->name); ?> </b> </p>
            <p class="text-red-600 h4"><b>MMKs <?php echo e($products->productDetail[0]['price']); ?> </b> </p>  
            <p class="card-text">Status: <?php echo e($products->productDetail[0]['status'] == '1' ? 'In-stock' : 'Pre-Order'); ?></p>
            <p class="card-text">Waiting Time: <?php if($products->productDetail[0]['status'] == '1'): ?> 3 - 4 days <?php else: ?> 10 - 12 days <?php endif; ?></p>
            <a href="<?php echo e(route('add.cart',[$products->id])); ?>">
                <button type="button" class="btn btn-sm mx-auto mt-3 text-white"
                    style="border-radius : 20px;   background-color : #aa0000;">Add to cart</button>
            </a>
        </div>
        <div class="col-md-5 mt-3">      
            <p  class="h5"> <b>Information</b></p>   
            <table  class="ml-3">
                <tr>
                    <td style="width:70%;"><p class="m-1"><b>Brand</b></p></td>
                    <td><?php echo e($products->brand->name); ?></td>
                </tr>
                <tr>
                    <td><p class="m-1"><b>Model Name</b></p></td>
                    <td><?php echo e($products->model_name); ?></td>
                </tr>
                <tr>
                    <td><p class="m-1"><b>Connectivity</b></p></td>
                    <td>Wireless</td>
                </tr>
                <tr>
                    <td><p class="m-1"><b>Warranty</b></p></td>
                    <td>1 year</td>
                </tr>
                 
            </table>
            <div class="col-md-6 mt-3">     
                <p  class="h5"> <b>Description </b></p> 
                <p class="mt-1"><?php echo $products->description; ?></p> 
            </div>     
        </div>
    </div>
</div>
<div class="container mt-3 text-white">
    <div class="text-center mt-4">
        <span class="h4 text-white" style=" font-family: 'Times New Roman', Times, serif;">
           CATEGORY BASED ON YOUR TREND
        </span>
        <hr class="mx-auto" style="width:360px; color: #aa0000; height: 3px; ">
    </div>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3 mt-3">
        <?php $__currentLoopData = $cat_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2">
                <a href="<?php echo e(route('productDetail',[$product->id])); ?>" class="m-auto">
                    <div class="card shadow-sm" style="background-color : #aa0000;border-radius : 25px; ">
                        <img src="<?php echo e(Storage::url($product->productDetail[0]['image_1'])); ?>" alt=""
                            style=" object-fit: contain;border-radius : 25px;">
                        <div class="card-body text-white">
                            <p><b> <?php echo e($product->name); ?></b></p>
                            <span > Colors- 
                                <?php $__currentLoopData = $product->productDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span  style="color: <?php echo e($item->color); ?>;font-size : 35px" >●</span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                            <p><b>MMKs <?php echo e($product->productDetail[0]['price']); ?> </b> </p>  
                            <small class="card-text"><p><?php echo Str::limit($product->description,120); ?></p></small>
                            <a href="<?php echo e(route('add.cart',[$product->id])); ?>">
                                <button type="button" class="btn btn-sm mx-auto  btn-outline-light mt-3"
                                    style="border-radius : 20px;">Add to cart</button>
                            </a>
                        </div>
                    </div>
                </a>
            </div>
      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>
<script type="text/javascript">
    function changeImage(image) {
        var img =  document.getElementById("productImg");
        img.src =image;
     }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/productDetail.blade.php ENDPATH**/ ?>