<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="row">
                <aside class="col-sm-5 border-right">
                    <section class="gallery-wrap">
                        <div class="img-big-wrap">
                            <a href="#">
                                <img src="<?php echo e(Storage::url($product->image)); ?>" alt="" width="100%">
                            </a>
                        </div>
                    </section>
                </aside>
                <aside class="col-sm-7">
                    <section class="card-body p-5">
                        <h4 class="title mb-3">
                            <?php echo e($product->name); ?>

                        </h4>
                        <p class="price-detail-wrap">
                            <span class="price h3 text-danger">
                                <span class="currency"><?php echo e($product->price); ?> MMK</span>
                            </span>
                        </p>
                        <h4>Description</h4>
                        <p><?php echo $product->description; ?></p>
                        <h4>Additional Information</h4>
                        <p><?php echo $product->additional_info; ?></p>
                        <hr>
                        <a href="<?php echo e(route('add.cart',[$product->id])); ?>" class="btn btn-outline-success">Add to cart</a>
                    </section>
                </aside>
            </div>
        </div>
        <?php if(count($productFromSameCategories) > 0): ?>
        <div class="jumbotron mt-3">
            <h3>You May Like This</h3>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <?php $__currentLoopData = $productFromSameCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col">
                    <div class="card shadow-sm">
                        <img src="<?php echo e(Storage::url($product->image)); ?>" alt="" style="height: 300px;
                        object-fit: contain;">
                        <div class="card-body">
                            <p><b><?php echo e($product->name); ?></b></p>
                            <p class="card-text"><?php echo Str::limit($product->description,120); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <a href="/product/<?php echo e($product->id); ?>">
                                    <button type="button" class="btn btn-sm btn-outline-success">View</button>
                                    </a>
                                    <a href="<?php echo e(route('add.cart',[$product->id])); ?>">
                                        <button type="button" class="btn btn-sm btn-outline-primary">Add to cart</button>
                                    </a>
                                </div>
                                <small class="text-muted"><?php echo e($product->price); ?> MMK</small>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/show.blade.php ENDPATH**/ ?>