<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bg-black text-white">
                <div class="card-header h3 text-center">Change Passowrd</div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('user.changePasswordPost')); ?>">
                        <?php echo csrf_field(); ?>
 
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-danger" id="alert-message">
                            <ul class="list-unstyled">
                                <li>
                                    <?php echo e(Session::get('message')); ?>

                                </li>
                            </ul>
                        </div>
                    <?php endif; ?>
                 

                        <div class="row mb-3">
                            <label for="oldpassword"
                                class="col-md-3 col-form-label text-right"><?php echo e(__('Old Password')); ?></label>

                            <div class="col-md-6">
                                <input id="oldpassword" type="password"
                                    class="form-control <?php $__errorArgs = ['oldpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="oldpassword"
                                    required >
                                    <span toggle="#oldpassword" class="fa fa-fw fa-eye field-icon toggle-password text-dark"
                                             style = " float: right;margin-right : 10px; margin-top: -25px;position: relative;z-index: 2;"></span>
                                <?php $__errorArgs = ['oldpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="newpassword"
                                class="col-md-3 col-form-label text-right"><?php echo e(__('New Password')); ?></label>

                            <div class="col-md-6">
                                <input id="newpassword" type="password"
                                    class="form-control <?php $__errorArgs = ['newpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="newpassword"
                                    required>
                                    <span toggle="#newpassword" class="fa fa-fw fa-eye field-icon toggle-password text-dark"
                                    style = " float: right;margin-right : 10px; margin-top: -25px;position: relative;z-index: 2;"></span>
                                <?php $__errorArgs = ['newpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="confpasowrd"
                                class="col-md-3 col-form-label text-right"><?php echo e(__('Confirm Password')); ?></label>
                            <div class="col-md-6">
                                <input id="confpasowrd" type="password"
                                    class="form-control <?php $__errorArgs = ['confpasowrd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="confpasowrd"
                                    required >
                                       <span toggle="#confpasowrd" class="fa fa-fw fa-eye field-icon toggle-password text-dark"
                                             style = " float: right;margin-right : 10px; margin-top: -25px;position: relative;z-index: 2;"></span>
                                <?php $__errorArgs = ['confpasowrd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6 offset-md-3 mt-3">
                            <input type="submit" class="btn text-white" style="background-color : #aa0000;"
                                value="Change Password" >
                        </div>
                    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>

<script type="text/javascript">
$(".toggle-password").click(function() {
$(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/auth/passwords/changepassword.blade.php ENDPATH**/ ?>