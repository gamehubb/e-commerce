<?php $__env->startSection('content'); ?>
<div class="container">
    
        <div class="col-md-8 text-white"  >     
            <form action="<?php echo e(route('deliveryInfo.store')); ?>" method="post" id="payment-form" style="width:60%;float: right;"><?php echo csrf_field(); ?>
                <div class="form-group m-2">
                    <label>Name</label>
                    <input type="text" name="name" id="name" class="form-control" value=<?php echo e(auth()->user()->name); ?>

                       >
                </div>
                <div class="form-group m-2">
                    <label>PhoneNumber</label>
                    <input type="number" name="phoneNumber" id="phonenumber" class="form-control" value=<?php echo e(auth()->user()->phone_number); ?> required>
                </div>       
                <div class="form-group m-2">
                    <label>Address</label>
                    <input type="text" name="address" id="address" class="form-control" required>
                </div>
                <div class="form-group m-2">
                    <label>Delivery Township</label>
                    <input type="text" name="township" id="deltownship" class="form-control" required>
                </div>
                <div class="form-group m-2">
                    <label>City</label>
                    <input type="text" name="city" id="city" class="form-control" required>
                </div>
           
                
                <div class="form-group m-2">
                    <label>State/Region</label>
                    <input type="text" name="state_region" id="state" class="form-control">
                </div>
             
               
                    <button type="submit" class="btn btn-sm mx-auto mt-3 text-white"
                        style="border-radius : 20px;width:50%; background-color : #aa0000; float: right;">Save</button>
               
            </form>  
        </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/deliveryInfo/create.blade.php ENDPATH**/ ?>