<?php $__env->startSection('content'); ?>
<div class="d-smflex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 ml-4 text-gray-800">Product</h1>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Product</li>
    </ol>
</div>
<div class="col-lg-12">
    <div class="card mb-4">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary">Products</h6>
      </div>
      <div class="table-responsive p-3">
        <table class="table align-items-center table-flush table-hover" id="dataTableHover">
          <thead class="thead-light">
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Category</th>         
              <th>Brand</th>
              <th>Status</th>
              <th>Image</th>
              <th colspan="2">Actions</th>     
            </tr>
          </thead>
          <tbody>
            <?php if(count($products)>0): ?>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
              <td style="">
                <img src="<?php echo e(Storage::url($product->productDetail[0]['image_1'])); ?>" width="100" alt="Image-1" class="index_image">
              <td><?php echo e($product->name); ?></td>
              <td><?php echo e($product->category->name); ?></td>
              <td><?php echo e($product->brand->name); ?></td>
              <td>
                <input data-id ="<?php echo e($product->id); ?>" class="toggle-class" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="Inactive" data-size="xs" id="catcat" <?php echo e($product->status ? 'checked' : ''); ?>>
              </td>
               
              <td><a href="<?php echo e(route('product.edit', $product->id)); ?>"><button class="btn btn-primary">Edit</button></a></td>
              <td>
                <form action="/auth/product/delete/<?php echo e($product->id); ?>" method="POST"><?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-danger">Delete</button>
                </form>  
              </td> 
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
              <td>No any products</td>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>
  <script type="text/javascript">
     $(document).ready(function(){
      $(function(){
          $('.toggle-class').change(function(){
             var status = $(this).prop('checked') == true ? 1 : 0;
            var product_id = $(this).data('id');
            // var category_id = $("#catcat").val();
             $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $("meta[name='csrf-token']").attr('content')
                  } 
              });
              $.ajax({
                type: "GET",
                url: '/auth/changedProductStatus',
                dataType: "json",
                data: {'id' : product_id, 'status' : status},
                success:function(data){
                 alert("Status Changed")
                }
          });
          });
      });
     });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/krishna/Workspace/e-commerce/resources/views/admin/product/index.blade.php ENDPATH**/ ?>