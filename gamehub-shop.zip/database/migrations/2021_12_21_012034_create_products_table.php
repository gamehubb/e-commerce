<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('vendor');
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('code')->unique();
            $table->string('model_name')->nullable();
            $table->unsignedBigInteger('category_id');
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
            $table->unsignedBigInteger('brand_id');
            $table->foreign('brand_id')->references('id')->on('brands')->onDelete('cascade');
            $table->integer('user_id');
            $table->integer('wireless')->default(false)->nullable();
            $table->integer('product_type')->default(1);
            $table->float('warranty')->nullable();
            $table->integer('is_special')->default(0)->nullable();
            $table->integer('status')->default(true)->nullable();
            $table->text('description')->nullable();
            $table->text('additional_info')->nullable();
            $table->text('moto')->nullable();
            $table->timestamps();
            $table->timestamp('deleted_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
